var jPN = document.getElementById ("Primeiro nome");
var jSN = document.getElementById ("Sobrenome");
var jemail = document.getElementById ("email");
var jphone = document.getElementById ("phone");
var jdata = document.getElementById ("date");
var jcpf = document.getElementById ("cpf");
var jcep = document.getElementById ("CEP");
var jpais = document.getElementById ("pais");
var jestado = document.getElementById ("estado");
var jmuni = document.getElementById ("município");
var jend = document.getElementById ("endereço");
var jcompl = document.getElementById ("complemento");
var jsenha = document.getElementById ("senha");
var nc = 0

{
  var nc + 1;
  alerte ("seu numero de cadastro é" var nc)
}