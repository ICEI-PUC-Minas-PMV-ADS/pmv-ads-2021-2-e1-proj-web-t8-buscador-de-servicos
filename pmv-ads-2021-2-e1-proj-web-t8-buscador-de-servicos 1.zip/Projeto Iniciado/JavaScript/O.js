function duplicarCampos(){
	//var clone = document.getElementById('origem').cloneNode(true);
	var clone = document.querySelector(".origem");
	document.body.appendChild(clone.cloneNode(true));
	var destino = document.getElementById('destino');
	destino.appendChild (clone.cloneNode(true));
	
	var camposClonados = clone.getElementsByTagName('input');
	
	for(i=0; i<camposClonados.length;i++){
		camposClonados[i].value = '';
	}
	
	
	
}

function removerCampos(id){
	var node1 = document.getElementById('destino');
	node1.removeChild(node1.childNodes[0]);
}